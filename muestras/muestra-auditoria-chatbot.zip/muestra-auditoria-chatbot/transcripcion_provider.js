/**
 * Proveedor de promptfoo para el modo transcripción (transcripcion/PROCEDIMIENTO.md).
 *
 * No le habla a ningún bot ni a ningún modelo: devuelve la respuesta que
 * Milagros copió del canal real (WhatsApp, Instagram) para ese mismo mensaje.
 * Así un banco escrito para la web se califica igual, con sus mismas
 * verificaciones, aunque el bot solo exista en un teléfono.
 *
 * En el YAML del banco, en lugar del proveedor del bot:
 *
 *   providers:
 *     - id: "file://transcripcion_provider.js"
 *       label: "whatsapp-2026-10-12"
 *       config:
 *         transcripcion: "transcripcion.json"   # lo arma scripts/transcripcion.py importar
 *
 * Si un mensaje no tiene respuesta copiada, devuelve un error y no una
 * respuesta vacía: lo que no se preguntó se informa como no medido, nunca
 * como aprobado (aprendizaje 19 de la skill).
 */

const fs = require("node:fs")
const path = require("node:path")

const normalizar = (texto) => String(texto).replace(/\r\n/g, "\n").trim()

class TranscripcionProvider {
  constructor(options = {}) {
    this.config = options.config || {}
    this.etiqueta = options.id || "transcripcion"
    const archivo = path.resolve(this.config.transcripcion || "transcripcion.json")
    if (!fs.existsSync(archivo)) {
      throw new Error(`No encuentro la transcripción: ${archivo}. Armala con scripts/transcripcion.py importar.`)
    }
    const datos = JSON.parse(fs.readFileSync(archivo, "utf8"))
    this.respuestas = new Map(Object.entries(datos.respuestas || {}).map(([k, v]) => [normalizar(k), v]))
    this.canal = datos.canal || "canal real"
  }

  id() {
    return this.etiqueta
  }

  async callApi(prompt) {
    const encontrada = this.respuestas.get(normalizar(prompt))
    if (!encontrada || !normalizar(encontrada.respuesta || "")) {
      return { error: `Sin respuesta copiada del ${this.canal} para este mensaje: no medido` }
    }
    return {
      output: encontrada.respuesta,
      metadata: { canal: this.canal, fecha: encontrada.fecha || "", captura: encontrada.captura || "" },
    }
  }
}

module.exports = TranscripcionProvider
