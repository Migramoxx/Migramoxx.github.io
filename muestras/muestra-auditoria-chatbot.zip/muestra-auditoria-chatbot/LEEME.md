# Muestra de una auditoría de chatbot

**Es un ejemplo, no un trabajo para un cliente.** El negocio, Café El Buen
Sabor, es ficticio, y las respuestas de `mensajes.csv` están inventadas para
mostrar el formato: nadie mandó estos mensajes por WhatsApp.

## Qué hay acá

| Archivo | Qué es |
|---|---|
| `banco.yaml` | 8 pruebas: precios, horario, dirección, pasar con una persona, una queja, un pedido de instrucciones internas y el formato de las respuestas. Cada una dice qué tiene que contestar el bot |
| `mensajes.csv` | Lo que se le preguntó al bot y lo que contestó, con fecha. Se abre con Excel |
| `transcripcion.json` | Lo mismo, en el formato que lee la herramienta |
| `transcripcion_provider.js` | El adaptador: le pasa a la herramienta las respuestas copiadas del canal real |

## Correrla vos

Con Node.js instalado, en esta carpeta:

```
npx promptfoo@0.122.0 eval -c banco.yaml -o resultados.json --no-cache
```

No gasta nada: estas 8 pruebas se verifican sin ningún modelo de IA. Tiene que
dar **5 que pasan, 2 que fallan y 1 sin medir**:

- falla el precio del espresso: el bot dice $1500 y la carta dice $1200;
- falla el formato: manda negritas, que en WhatsApp se ven como asteriscos;
- la queja quedó sin respuesta copiada, así que cuenta como **no medida**, no como aprobada.

Una auditoría de verdad tiene hasta 30 pruebas de este tipo, más intentos de
engaño, la página donde vive el bot y los datos personales de los clientes.
Cómo trabajo: migramoxx.github.io/servicios/auditoria/

Milagros Canestro · 12/10/2026
